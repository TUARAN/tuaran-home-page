---
name: tuaran-articles
description: "Search public articles, research topics, and resources published on 2aran.com."
description_zh: "查询 2aran.com 的公开文章、专题调研和资源，支持最近更新与关键词搜索。"
description_en: "Search public articles, research topics, and resources published on 2aran.com."
version: 1.0.0
author: TUARAN
---

# 涂阿燃文章连接器

当用户的请求符合连接器能力时，选择语义最匹配的工具，只传递完成任务所需的参数。不要虚构工具未返回的数据。

## 可用工具

- `get_recent_articles`
- `search_articles`

## 使用边界

- 仅查询公开信息；如果服务要求授权，按 WorkBuddy 的 OAuth 引导完成授权。
- 调用失败时返回可读错误，不用猜测结果。
