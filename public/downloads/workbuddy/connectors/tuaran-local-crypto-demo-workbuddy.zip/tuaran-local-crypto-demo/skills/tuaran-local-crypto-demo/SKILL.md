---
name: tuaran-local-crypto-demo
description: "Run AES-256-GCM encryption, decryption, and runtime checks in a local Node.js MCP process."
description_zh: "在 WorkBuddy 拉起的本地 Node.js 进程中执行 AES-256-GCM 加解密与运行检查。"
description_en: "Run AES-256-GCM encryption, decryption, and runtime checks in a local Node.js MCP process."
version: 1.0.0
author: TUARAN
---

# 本地加解密 MCP 测试连接器

当用户的请求符合连接器能力时，选择语义最匹配的工具，只传递完成任务所需的参数。不要虚构工具未返回的数据。

## 可用工具

- `local_encrypt_text`
- `local_decrypt_text`
- `local_runtime_info`

## 使用边界

- 加密和解密只在本地子进程执行，但工具参数与结果仍可能进入 WorkBuddy 和模型上下文。
- 不要输出、记录或复述用户配置的密钥。
