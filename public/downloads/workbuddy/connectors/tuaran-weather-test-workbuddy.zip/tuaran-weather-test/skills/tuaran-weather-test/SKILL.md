---
name: tuaran-weather-test
description: "Query current weather and forecasts by city name to verify a WorkBuddy MCP connection."
description_zh: "按中英文城市名查询当前天气和未来预报，用于验证 WorkBuddy 的 MCP 连接。"
description_en: "Query current weather and forecasts by city name to verify a WorkBuddy MCP connection."
version: 1.0.0
author: TUARAN
---

# 天气查询测试连接器

当用户的请求符合连接器能力时，选择语义最匹配的工具，只传递完成任务所需的参数。不要虚构工具未返回的数据。

## 可用工具

- `get_current_weather`
- `get_weather_forecast`

## 使用边界

- 仅查询公开信息；如果服务要求授权，按 WorkBuddy 的 OAuth 引导完成授权。
- 调用失败时返回可读错误，不用猜测结果。
