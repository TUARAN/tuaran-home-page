---
name: publisher-format-review
display_name: "出版社格式校对 Skill"
display_name_en: "Publisher Format Review"
description: "按出版社图书出版规范校对/重写章节内容：序号层级、图表引出、AI 痕迹消除、口语化净化共 11 条规则。"
description_zh: "按出版社图书出版规范校对/重写章节内容：序号层级、图表引出、AI 痕迹消除、口语化净化共 11 条规则。"
description_en: "Review and rewrite Chinese book chapters against practical publishing and editorial formatting rules."
version: 1.0.0
author: "TUARAN"
user-invocable: true
---
# Publisher Format Review

Use this skill when the user provides book/manuscript chapter content and asks for publisher-grade proofreading or rewriting.

## When to use

- User pastes one or more chapter sections (titles + body + lists + figure/table mentions)
- User asks "按出版社格式改" / "图书排版校对" / "消除 AI 痕迹" / "书稿规范化"

## 11 rules

1. **Numbering hierarchy**: "第一章" / "1.1" / "1.1.1" / "1." / "（1）" only attach to titles. For listing paragraphs, use "1)" "2)" "①" "●". Never use "1." "2." for body paragraphs.
2. **Figure callout**: "XXX，如图 1-1 所示。" Each figure needs chapter-figure number; figure centered; caption "图 1-1  描述" below image.
3. **No broken hierarchy**: never skip levels; never mix symbols at the same level; every title must carry its number.
4. **Linked transitions**: every paragraph / list / figure / table must have a sentence connecting upstream / downstream context.
5. **Strip AI traces**: parallel-clause overuse, adjective stacking, generic openings ("在数字化时代背景下"), summary clichés ("综上所述"), excessive metaphor → replace with concrete facts.
6. **Bulk LLM rewrite**: send each 3rd-level section (300-800 chars) as a unit with the prompt: "优化文字描述，用名词替代人称代词，无知识性差错、逻辑性差错、上下文不对应、语法语病、标点问题。符合出版社图书出版要求。"
7. **Table convention (inverse of figures)**: callout "XXX，如表 1-1 所示。" Table caption "表 1-1  描述" goes ABOVE the table, not below.
8. **Lead-in paragraph under each title**: every level-1 / level-2 title needs a bridging paragraph explaining what / why before content begins.
9. **No URLs in print**: never include "https://..." in book body; URLs decay after print. Use "在主流应用商店搜索 XXX" style.
10. **Whole-section rewriting, not line-by-line**: process a complete 3rd-level section at once so style/tone/rhythm stay unified.
11. **Detail discipline**:
   - Stray single sentences → wrap into a paragraph with **bold emphasis**
   - Colloquial expressions ("其实你只要点一下") → formal ("用户点击即可")
   - Remove disturbing imagery (骷髅 / 血色 / etc.)
   - Module names unified across entire chapter (don't mix "豆包 APP" / "豆包" / "豆包软件")
   - Personal pronouns (我 / 你 / 他) → nouns (用户 / 创作者 / 读者)
   - Quote marks "" not 「」

## Output

- Default: return the full rewritten chapter text (not just diffs), in Markdown, preserving original heading structure.
- If user asks "对比": two-column table (before / after).
- If user asks "清单": list each change with original snippet + revised snippet.

## Constraints

- Stay faithful to original meaning; never drop information for the sake of "规范化".
- Output must be print-ready; no "XXX" placeholders or "[待补]" markers.
- For AI-trace flagging, point out WHICH sentence is the AI trace.
- Never invent facts (product features, statistics) not in original.

## Shareability

This skill is self-contained and can be:
1. Copied as system prompt into Codex / Cursor / ChatGPT / Claude Code
2. Shared as a link via Claude Code's skill sharing feature
3. Printed as internal editorial guideline (the 11 rules above)
