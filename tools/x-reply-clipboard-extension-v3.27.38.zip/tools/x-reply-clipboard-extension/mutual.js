(function (root) {
  "use strict";

  const FOLLOW_ACTION_DELAY_MS = 2000;
  const FOLLOW_BATCH_SIZE = 15;
  const FOLLOW_BATCH_COOLDOWN_MS = 1800000;
  const FOLLOW_MAX_PER_RUN = 400;
  const FOLLOW_DAILY_LIMIT = 400;
  const RATE_LIMIT_COOLDOWN_MS = 15 * 60 * 1000;
  const TARGET_FOLLOW_HANDLES = ["crazypig9y", "jianlvup", "jianlvya", "kyotom08", "Chill_Alpha"];
  const RATE_LIMIT_RE = /(?:sorry,\s*you are rate limited|please wait a few moments then try again|受到速率限制|请稍等片刻后再试)/i;
  // Keep the original key so existing target-follow totals migrate into the shared quota.
  const FOLLOW_RATE_STORAGE_KEY = "xrcTargetFollowDaily";
  const SCROLL_DELAY_MS = 450;
  const MAX_STALLED_SCROLLS = 4;
  const FOLLOWING_RE = /^(Following|正在关注)$/i;
  const FOLLOW_BACK_RE = /^(Follow back|回关)$/i;
  const FOLLOW_RE = /^(Follow|关注)$/i;
  const FOLLOWS_YOU_RE = /(Follows you|关注了你)/i;
  const USER_HANDLE_RE = /@[A-Za-z0-9_]{1,15}/;
  const PROFILE_PATH_RE = /^\/([A-Za-z0-9_]{1,15})\/?$/;

  const state = {
    running: false,
    stopping: false,
    mode: "",
    status: "选择一项互关任务开始",
    unfollowed: 0,
    followedBack: 0,
    targetFollowed: 0,
    sharedDailyFollowed: 0,
    sharedBatchProgress: 0,
    sharedDailyDate: "",
    skipped: 0,
    errors: 0,
    cooldownUntil: 0,
    seenHandles: new Set(),
    skippedHandles: new Set(),
    acknowledgedRateLimits: new Set(),
    wakeRequested: false,
    wakeResolver: null,
    onUpdate: null
  };

  const sleep = (ms) => root.XInteractionTimer?.wait?.(ms) || new Promise((resolve) => window.setTimeout(resolve, ms));
  const textOf = (node) => (node?.innerText || node?.textContent || node?.getAttribute?.("aria-label") || "").trim();
  const buttonLabel = (button) => (button?.getAttribute?.("aria-label") || button?.innerText || button?.textContent || "").trim();

  function snapshot() {
    return {
      running: state.running,
      stopping: state.stopping,
      mode: state.mode,
      status: state.status,
      unfollowed: state.unfollowed,
      followedBack: state.followedBack,
      targetFollowed: state.targetFollowed,
      sharedDailyFollowed: state.sharedDailyFollowed,
      sharedBatchProgress: state.sharedBatchProgress,
      skipped: state.skipped,
      errors: state.errors,
      cooldownUntil: state.cooldownUntil
    };
  }

  function emit(status) {
    if (status) state.status = status;
    state.onUpdate?.(snapshot());
  }

  async function sleepActive(ms) {
    const deadline = Date.now() + Math.max(0, Number(ms) || 0);
    while (Date.now() < deadline && !state.stopping) {
      const chunk = Math.min(1000, Math.max(1, deadline - Date.now()));
      await Promise.race([
        sleep(chunk),
        new Promise((resolve) => { state.wakeResolver = resolve; })
      ]);
      state.wakeResolver = null;
      if (state.wakeRequested) {
        state.wakeRequested = false;
        break;
      }
      if (state.cooldownUntil) emit();
    }
  }

  function startNow() {
    if (!state.running || state.stopping) return false;
    state.cooldownUntil = 0;
    state.wakeRequested = true;
    state.wakeResolver?.();
    state.wakeResolver = null;
    emit("已立即开始，跳过当前暂停时间");
    return true;
  }

  function isFollowingPath(pathname) {
    return /^\/[^/]+\/following\/?$/.test(String(pathname || ""));
  }

  function isFollowersPath(pathname) {
    return /^\/[^/]+\/(followers|verified_followers)\/?$/.test(String(pathname || ""));
  }

  function isFollowingPage() {
    return isFollowingPath(window.location.pathname);
  }

  function isFollowersPage() {
    return isFollowersPath(window.location.pathname);
  }

  function currentAccountHandle() {
    const account = document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"]');
    const match = textOf(account).match(USER_HANDLE_RE);
    if (match) return match[0].slice(1);
    const href = document.querySelector('[data-testid="AppTabBar_Profile_Link"], a[aria-label="Profile"], a[aria-label="个人资料"]')?.getAttribute("href") || "";
    return href.match(PROFILE_PATH_RE)?.[1] || "";
  }

  function reportMutualAction(mode, handle, result, errorCode) {
    const task = mode === "unfollow"
      ? "mutual-unfollow"
      : mode === "followBack"
        ? "mutual-follow-back"
        : mode === "targetFollow"
          ? "mutual-target-follow"
          : "";
    if (!task) return;
    try {
      globalThis.XrcCommunityReceipt?.report({
        task,
        result,
        targetId: String(handle || "").replace(/^@/u, ""),
        accountHandle: currentAccountHandle(),
        errorCode
      });
    } catch (error) {}
  }

  function pagePath() {
    try {
      return String(globalThis.location?.pathname || "").replace(/\/+$/, "");
    } catch (error) {
      return "";
    }
  }

  function targetFollowHandleFromPath(pathname = pagePath()) {
    const match = String(pathname || "").match(/^\/([^/]+)\/followers$/i);
    if (!match) return "";
    return TARGET_FOLLOW_HANDLES.find((handle) => handle.toLowerCase() === match[1].toLowerCase()) || "";
  }

  function pickTargetFollowHandle() {
    return TARGET_FOLLOW_HANDLES[Math.floor(Math.random() * TARGET_FOLLOW_HANDLES.length)];
  }

  function listReady(mode) {
    if (mode === "unfollow") return isFollowingPage();
    if (mode === "followBack") return isFollowersPage() && !targetFollowHandleFromPath();
    if (mode === "targetFollow") return Boolean(targetFollowHandleFromPath());
    return false;
  }

  function targetPath(mode) {
    if (mode === "targetFollow") return `/${targetFollowHandleFromPath() || pickTargetFollowHandle()}/followers`;
    const handle = currentAccountHandle();
    if (!handle) return "";
    if (mode === "unfollow") return `/${handle}/following`;
    if (mode === "followBack") return `/${handle}/followers`;
    return "";
  }

  function localDayKey(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  function followStorage() {
    if (globalThis.chrome?.runtime && !globalThis.chrome.runtime.id) {
      throw followStorageError(new Error("Extension context invalidated."));
    }
    const storage = globalThis.chrome?.storage?.local;
    if (!storage) throw followStorageError(new Error("扩展存储不可用"));
    return storage;
  }

  function followStorageError(error) {
    const result = error instanceof Error ? error : new Error(String(error || "扩展存储不可用"));
    result.xrcFollowStorage = true;
    return result;
  }

  function storageErrorMessage(error) {
    return /extension context invalidated/i.test(String(error?.message || error))
      ? "扩展已重新加载，请刷新此 X 页面后再启动关注任务"
      : error?.xrcFollowStorage
        ? "关注记录无法保存，任务已停止，请刷新页面后重试"
        : "关注任务遇到错误，已停止，请刷新页面后重试";
  }

  async function loadSharedFollowRate() {
    const today = localDayKey();
    let result;
    try {
      result = await followStorage().get(FOLLOW_RATE_STORAGE_KEY);
    } catch (error) {
      throw followStorageError(error);
    }
    const saved = result?.[FOLLOW_RATE_STORAGE_KEY] || null;
    const isToday = saved?.date === today;
    state.sharedDailyDate = today;
    state.sharedDailyFollowed = isToday ? Math.max(0, Number(saved.count) || 0) : 0;
    state.sharedBatchProgress = isToday
      ? Math.max(0, Math.min(FOLLOW_BATCH_SIZE, Number(saved.batchProgress ?? (state.sharedDailyFollowed % FOLLOW_BATCH_SIZE)) || 0))
      : 0;
    state.cooldownUntil = isToday && Number(saved.cooldownUntil) > Date.now() ? Number(saved.cooldownUntil) : 0;
    if (state.sharedBatchProgress >= FOLLOW_BATCH_SIZE && !state.cooldownUntil) {
      state.sharedBatchProgress = 0;
      state.cooldownUntil = Date.now() + FOLLOW_BATCH_COOLDOWN_MS;
      await persistSharedFollowRate();
    }
    return state.sharedDailyFollowed;
  }

  async function persistSharedFollowRate() {
    try {
      await followStorage().set({
        [FOLLOW_RATE_STORAGE_KEY]: {
          date: state.sharedDailyDate || localDayKey(),
          count: state.sharedDailyFollowed,
          batchProgress: state.sharedBatchProgress,
          cooldownUntil: state.cooldownUntil
        }
      });
    } catch (error) {
      throw followStorageError(error);
    }
  }

  async function recordSharedFollow() {
    await loadSharedFollowRate();
    state.sharedDailyFollowed += 1;
    state.sharedBatchProgress += 1;
    await persistSharedFollowRate();
  }

  function formatClock(milliseconds) {
    const totalSeconds = Math.max(0, Math.ceil((Number(milliseconds) || 0) / 1000));
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  }

  function rateLimitNodes() {
    return Array.from(document.querySelectorAll('[data-testid="toast"], [role="alert"], [role="status"]'))
      .filter((node) => RATE_LIMIT_RE.test(textOf(node)));
  }

  function rateLimitVisible() {
    return rateLimitNodes().some((node) => !state.acknowledgedRateLimits.has(node));
  }

  function dismissTransientDialog() {
    document.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Escape",
      code: "Escape",
      keyCode: 27,
      which: 27,
      bubbles: true,
      cancelable: true
    }));
  }

  async function waitForPlatformRateLimit() {
    for (const node of rateLimitNodes()) state.acknowledgedRateLimits.add(node);
    state.cooldownUntil = Date.now() + RATE_LIMIT_COOLDOWN_MS;
    while (!state.stopping && Date.now() < state.cooldownUntil) {
      emit(`X 提示操作过密，${formatClock(state.cooldownUntil - Date.now())} 后继续`);
      await sleep(Math.min(1000, Math.max(0, state.cooldownUntil - Date.now())));
    }
    if (state.stopping) return false;
    state.cooldownUntil = 0;
    emit("限速等待结束，继续当前列表");
    return true;
  }

  async function waitForSharedCooldown() {
    if (!state.cooldownUntil || state.cooldownUntil <= Date.now()) {
      state.cooldownUntil = 0;
      return true;
    }
    emit(`共享频率限制：本批已完成 ${FOLLOW_BATCH_SIZE} 个，暂停 30 分钟`);
    await sleepActive(state.cooldownUntil - Date.now());
    if (state.stopping) return false;
    if (state.cooldownUntil <= Date.now()) {
      state.cooldownUntil = 0;
      await persistSharedFollowRate();
    }
    return true;
  }

  function getClickable(element) {
    return element?.closest?.('button, [role="button"]') || element || null;
  }

  function actions(scope) {
    return Array.from(scope?.querySelectorAll?.('button, [role="button"]') || []);
  }

  function isFollowingButton(button) {
    const label = buttonLabel(button);
    return Boolean(label) && !FOLLOW_RE.test(label) && (FOLLOWING_RE.test(label) || /^Following\s+@/i.test(label) || /^正在关注\s+@/.test(label));
  }

  function isFollowBackButton(button) {
    const label = buttonLabel(button);
    return Boolean(label) && (FOLLOW_BACK_RE.test(label) || /^Follow back\s+@/i.test(label));
  }

  function isPlainFollowButton(button) {
    const label = buttonLabel(button);
    return Boolean(label) && !isFollowBackButton(button) && !isFollowingButton(button) && (FOLLOW_RE.test(label) || /^Follow\s+@/i.test(label) || /^关注\s+@/.test(label));
  }

  function findFollowingButton(row) {
    return getClickable(row.querySelector('button[data-testid$="-unfollow"], [role="button"][data-testid$="-unfollow"]')) || actions(row).find(isFollowingButton) || null;
  }

  function findFollowBackButton(row) {
    const candidate = row.querySelector('button[data-testid$="-follow"], [role="button"][data-testid$="-follow"]');
    return candidate && isFollowBackButton(candidate) ? getClickable(candidate) : actions(row).find(isFollowBackButton) || null;
  }

  function findPlainFollowButton(row) {
    const candidate = row.querySelector('button[data-testid$="-follow"], [role="button"][data-testid$="-follow"]');
    return candidate && isPlainFollowButton(candidate) ? getClickable(candidate) : actions(row).find(isPlainFollowButton) || null;
  }

  function findHandle(row, button) {
    const labelMatch = buttonLabel(button).match(USER_HANDLE_RE);
    if (labelMatch) return labelMatch[0];
    for (const link of row.querySelectorAll("a[href]")) {
      const href = link.getAttribute("href") || "";
      const match = href.match(PROFILE_PATH_RE);
      if (match) return `@${match[1]}`;
    }
    return textOf(row).match(USER_HANDLE_RE)?.[0] || "";
  }

  function hasFollowsYou(row) {
    return Boolean(row.querySelector('[data-testid="userFollowIndicator"]')) || FOLLOWS_YOU_RE.test(textOf(row));
  }

  function rows() {
    const main = document.querySelector('[data-testid="primaryColumn"]') || document.body;
    const candidates = [
      ...main.querySelectorAll('[data-testid="UserCell"]'),
      ...main.querySelectorAll('article[role="article"]'),
      ...main.querySelectorAll('[data-testid="cellInnerDiv"]')
    ];
    return Array.from(new Set(candidates)).filter((row) => {
      const rect = row.getBoundingClientRect();
      return rect.bottom > 0 && rect.top < window.innerHeight && (findFollowingButton(row) || findFollowBackButton(row) || findPlainFollowButton(row));
    });
  }

  function visibleRows(mode) {
    return rows().map((row) => {
      const followingButton = findFollowingButton(row);
      const followBackButton = findFollowBackButton(row);
      const followButton = findPlainFollowButton(row);
      const handle = findHandle(row, followingButton || followBackButton || followButton);
      const followsYou = hasFollowsYou(row);
      const candidate = mode === "unfollow"
        ? Boolean(handle && followingButton && !followsYou)
        : mode === "followBack"
          ? Boolean(handle && followBackButton && followsYou)
          : Boolean(handle && followButton && !followBackButton && !followingButton);
      return { row, handle, followsYou, followingButton, followBackButton, followButton, candidate };
    }).filter((item) => item.handle);
  }

  function realClick(element) {
    element.scrollIntoView({ block: "center", inline: "nearest" });
    element.focus?.({ preventScroll: true });
    const rect = element.getBoundingClientRect();
    const init = { bubbles: true, cancelable: true, view: window, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2 };
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup"]) {
      const EventClass = type.startsWith("pointer") && typeof PointerEvent === "function" ? PointerEvent : MouseEvent;
      element.dispatchEvent(new EventClass(type, init));
    }
    element.click();
  }

  async function waitUntil(check, timeoutMs) {
    const started = Date.now();
    while (!state.stopping && Date.now() - started < timeoutMs) {
      const result = check();
      if (result) return result;
      await sleep(100);
    }
    return null;
  }

  function unfollowConfirm(handle) {
    for (const dialog of document.querySelectorAll('[data-testid="confirmationSheetDialog"], [role="dialog"], [aria-modal="true"]')) {
      const text = textOf(dialog);
      if (!/(Unfollow|取消关注)/i.test(text) || /Block|Mute|Report|屏蔽|拉黑|举报/.test(text)) continue;
      const named = dialog.querySelector('[data-testid="confirmationSheetConfirm"], [data-testid="unfollowConfirm"]');
      if (named) return getClickable(named);
      const button = actions(dialog).find((item) => /^(Unfollow|取消关注)$/i.test(buttonLabel(item)) || /^Unfollow\s+@/i.test(buttonLabel(item)));
      if (button && (!handle || text.includes(handle.replace(/^@/, "")))) return button;
    }
    return null;
  }

  async function actUnfollow(item) {
    if (rateLimitVisible()) return "rate-limited";
    emit(`正在取消 ${item.handle}`);
    realClick(item.followingButton);
    const outcome = await waitUntil(() => {
      if (rateLimitVisible()) return "rate-limited";
      return unfollowConfirm(item.handle) || !findFollowingButton(item.row) || !item.row.isConnected;
    }, 4000);
    if (outcome === "rate-limited" || rateLimitVisible()) {
      dismissTransientDialog();
      return "rate-limited";
    }
    if (!outcome) return false;
    if (outcome.nodeType || outcome.tagName || typeof outcome.click === "function") {
      if (rateLimitVisible()) {
        dismissTransientDialog();
        return "rate-limited";
      }
      realClick(outcome);
      const changed = await waitUntil(() => {
        if (!findFollowingButton(item.row) || !item.row.isConnected) return "done";
        if (rateLimitVisible()) return "rate-limited";
        return null;
      }, 6000);
      if (changed === "done") {
        state.unfollowed += 1;
        await recordSharedFollow();
        reportMutualAction("unfollow", item.handle, "success");
        return true;
      }
      if (changed === "rate-limited" || rateLimitVisible()) return "rate-limited";
      return false;
    }
    state.unfollowed += 1;
    await recordSharedFollow();
    reportMutualAction("unfollow", item.handle, "success");
    return true;
  }

  async function actFollowBack(item) {
    if (rateLimitVisible()) return "rate-limited";
    emit(`正在回关 ${item.handle}`);
    realClick(item.followBackButton);
    const changed = await waitUntil(() => {
      if (findFollowingButton(item.row) || !findFollowBackButton(item.row) || !item.row.isConnected) return "done";
      if (rateLimitVisible()) return "rate-limited";
      return null;
    }, 6000);
    if (changed === "rate-limited" || rateLimitVisible()) return "rate-limited";
    if (changed !== "done") return false;
    state.followedBack += 1;
    await recordSharedFollow();
    reportMutualAction("followBack", item.handle, "success");
    return true;
  }

  async function actTargetFollow(item) {
    if (rateLimitVisible()) return "rate-limited";
    emit(`正在关注 ${item.handle}`);
    realClick(item.followButton);
    const changed = await waitUntil(() => {
      if (findFollowingButton(item.row) || !findPlainFollowButton(item.row) || !item.row.isConnected) return "done";
      if (rateLimitVisible()) return "rate-limited";
      return null;
    }, 6000);
    if (changed === "rate-limited" || rateLimitVisible()) return "rate-limited";
    if (changed !== "done") return false;
    state.targetFollowed += 1;
    await recordSharedFollow();
    reportMutualAction("targetFollow", item.handle, "success");
    return true;
  }

  function scrollInfo() {
    const element = document.scrollingElement || document.documentElement;
    const top = window.scrollY || element.scrollTop || 0;
    const height = Math.max(element.scrollHeight || 0, document.body?.scrollHeight || 0);
    return { top, maxTop: Math.max(0, height - window.innerHeight) };
  }

  async function scrollForward(signature, mode) {
    const before = scrollInfo();
    window.scrollBy({ top: Math.max(640, Math.floor(window.innerHeight * 0.9)), behavior: "auto" });
    await sleepActive(SCROLL_DELAY_MS);
    const after = scrollInfo();
    const next = visibleRows(mode);
    return { progressed: after.top > before.top + 8 || next.map((item) => item.handle).join("|") !== signature, items: next, atBottom: after.maxTop > 0 && after.top >= after.maxTop - 24 };
  }

  function reset(mode, onUpdate) {
    state.running = true;
    state.stopping = false;
    state.mode = mode;
    state.status = "准备开始";
    state.unfollowed = 0;
    state.followedBack = 0;
    state.targetFollowed = 0;
    state.skipped = 0;
    state.errors = 0;
    state.seenHandles.clear();
    state.skippedHandles.clear();
    state.acknowledgedRateLimits.clear();
    state.onUpdate = onUpdate;
  }

  async function run(mode, onUpdate) {
    try {
      return await runWithStorage(mode, onUpdate);
    } catch (error) {
      state.running = false;
      state.stopping = false;
      state.mode = "";
      state.errors += 1;
      const message = storageErrorMessage(error);
      emit(message);
      return { error: message };
    }
  }

  async function runWithStorage(mode, onUpdate) {
    if (state.running) return false;
    if (mode === "unfollow" && !isFollowingPage()) return { navigate: targetPath(mode), error: "请打开自己的 Following 页面" };
    if (mode === "followBack" && !isFollowersPage()) return { navigate: targetPath(mode), error: "请打开自己的 Followers 页面" };
    if (mode === "targetFollow" && !targetFollowHandleFromPath()) {
      return { navigate: targetPath(mode), error: "请打开随机抽中的 Followers 页面" };
    }
    await loadSharedFollowRate();
    if (state.sharedDailyFollowed >= FOLLOW_DAILY_LIMIT) {
      return { error: `今天三项合计已操作 ${state.sharedDailyFollowed} 个，达到共享每日 ${FOLLOW_DAILY_LIMIT} 个上限` };
    }
    reset(mode, onUpdate);
    emit(mode === "unfollow" ? "开始清理未回关账号" : mode === "followBack" ? "开始回关粉丝" : "开始关注候选");
    if (!(await waitForSharedCooldown())) {
      state.running = false;
      state.stopping = false;
      emit("已停止；共享暂停时间仍会保留");
      return true;
    }
    let stalled = 0;

    while (!state.stopping) {
      await loadSharedFollowRate();
      if (state.sharedDailyFollowed >= FOLLOW_DAILY_LIMIT) {
        emit(`今天三项合计已操作 ${state.sharedDailyFollowed} 个，达到共享每日 ${FOLLOW_DAILY_LIMIT} 个上限`);
        break;
      }
      if (!(await waitForSharedCooldown())) break;
      if (rateLimitVisible()) {
        if (!(await waitForPlatformRateLimit())) break;
        continue;
      }
      const items = visibleRows(mode);
      for (const item of items) {
        const skipped = mode === "unfollow" ? item.followsYou : !item.candidate;
        if (skipped && !state.skippedHandles.has(item.handle)) {
          state.skippedHandles.add(item.handle);
          state.skipped += 1;
        }
      }
      const candidate = items.find((item) => item.candidate && !state.seenHandles.has(item.handle));
      if (candidate) {
        stalled = 0;
        state.seenHandles.add(candidate.handle);
        const ok = mode === "unfollow"
          ? await actUnfollow(candidate)
          : mode === "followBack"
            ? await actFollowBack(candidate)
            : await actTargetFollow(candidate);
        if (ok === "rate-limited" || rateLimitVisible()) {
          reportMutualAction(mode, candidate.handle, "limited", "rate-limited");
          state.seenHandles.delete(candidate.handle);
          if (!(await waitForPlatformRateLimit())) break;
          continue;
        }
        if (!ok) state.errors += 1;
        emit(ok ? `已完成 ${candidate.handle}` : `${candidate.handle} 的操作没有确认成功`);
        if (state.stopping) break;
        const count = mode === "unfollow" ? state.unfollowed : mode === "followBack" ? state.followedBack : state.targetFollowed;
        if (count >= FOLLOW_MAX_PER_RUN) break;
        if (state.sharedDailyFollowed >= FOLLOW_DAILY_LIMIT) break;
        if (state.sharedBatchProgress >= FOLLOW_BATCH_SIZE) {
          state.sharedBatchProgress = 0;
          state.cooldownUntil = Date.now() + FOLLOW_BATCH_COOLDOWN_MS;
          await persistSharedFollowRate();
          if (!(await waitForSharedCooldown())) break;
        } else {
          await sleepActive(FOLLOW_ACTION_DELAY_MS);
        }
        continue;
      }

      emit("当前屏没有可处理账号，继续向下查找");
      const signature = items.map((item) => item.handle).join("|");
      const result = await scrollForward(signature, mode);
      stalled = result.progressed || !result.atBottom ? 0 : stalled + 1;
      if (stalled >= MAX_STALLED_SCROLLS) break;
    }

    state.running = false;
    state.stopping = false;
    state.cooldownUntil = 0;
    emit(state.mode === "unfollow"
      ? `完成：取消 ${state.unfollowed} 个，共享今日 ${state.sharedDailyFollowed}/${FOLLOW_DAILY_LIMIT}`
      : state.mode === "followBack"
        ? `完成：本次回关 ${state.followedBack} 个，共享今日 ${state.sharedDailyFollowed}/${FOLLOW_DAILY_LIMIT}`
        : `完成：本次关注 ${state.targetFollowed} 个，共享今日 ${state.sharedDailyFollowed}/${FOLLOW_DAILY_LIMIT}`);
    state.mode = "";
    emit();
    return true;
  }

  function stop() {
    if (!state.running) return false;
    state.stopping = true;
    emit("正在停止，当前动作确认后结束");
    return true;
  }

  const api = {
    run,
    stop,
    startNow,
    snapshot,
    refreshSharedFollowRate: async () => {
      try {
        await loadSharedFollowRate();
      } catch (error) {
        state.status = storageErrorMessage(error);
      }
      return snapshot();
    },
    targetPath,
    listReady,
    isFollowingPath,
    isFollowersPath,
    isFollowingPage,
    isFollowersPage,
    constants: {
      FOLLOW_ACTION_DELAY_MS,
      FOLLOW_BATCH_SIZE,
      FOLLOW_BATCH_COOLDOWN_MS,
      FOLLOW_MAX_PER_RUN,
      FOLLOW_DAILY_LIMIT,
      RATE_LIMIT_COOLDOWN_MS,
      TARGET_FOLLOW_HANDLES
    }
  };
  if (typeof module === "object" && module.exports) module.exports = api;
  root.XInteractionMutual = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
